-- Styles the bathroom parts imported from bathroom.blend.
-- Usage: import the .obj with File > Import 3D, select the imported model(s)
-- in the Explorer, then paste this whole script into the Command Bar
-- (View > Command Bar) and press Enter.
local STYLES = {
	Acrylic          = {Color3.fromRGB(245, 245, 243), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Acrylic_001      = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Aluminium        = {Color3.fromRGB(231, 232, 234), Enum.Material.Metal, 0.15, 0.00},
	Art_Print        = {Color3.fromRGB(243, 231, 203), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Art_Print        = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Bin_Liner        = {Color3.fromRGB( 21,  21,  21), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Bin_Liner        = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Brass            = {Color3.fromRGB(230, 195, 138), Enum.Material.Metal, 0.15, 0.00},
	Brass_001        = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Cardboard        = {Color3.fromRGB(176, 141, 102), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Cardboard_001    = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Ceiling_Tile     = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Ceramic          = {Color3.fromRGB(244, 244, 241), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Ceramic_Matte    = {Color3.fromRGB(236, 234, 228), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Ceramic_001      = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Ceramic_Matte    = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Chrome           = {Color3.fromRGB(205, 208, 212), Enum.Material.SmoothPlastic, 0.50, 0.00},
	Chrome_001       = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Door_Paint       = {Color3.fromRGB(243, 243, 240), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Door_Paint       = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Floor_Speckle    = {Color3.fromRGB(214, 209, 200), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Frame_White      = {Color3.fromRGB(246, 246, 243), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Frame_White      = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Glass            = {Color3.fromRGB(252, 255, 253), Enum.Material.Glass, 0.05, 0.60},
	Glass_Frosted    = {Color3.fromRGB(250, 253, 253), Enum.Material.Glass, 0.05, 0.40},
	Glass_Green      = {Color3.fromRGB(196, 237, 203), Enum.Material.Glass, 0.05, 0.35},
	Glass_Thin       = {Color3.fromRGB(230, 245, 240), Enum.Material.Glass, 0.10, 0.85},
	Glass_001        = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.35},
	Glass_Frosted    = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.40},
	Glass_Green      = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.35},
	Glass_Thin       = {Color3.fromRGB(230, 245, 240), Enum.Material.Glass, 0.10, 0.85},
	Grout_Grey       = {Color3.fromRGB(158, 155, 149), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Grout_White      = {Color3.fromRGB(226, 225, 220), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Indicator_Green  = {Color3.fromRGB( 46, 158,  72), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Indicator_Red    = {Color3.fromRGB(193,  39,  45), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Laminate_Grey    = {Color3.fromRGB(217, 218, 219), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Laminate_Oak     = {Color3.fromRGB(193, 134,  73), Enum.Material.Wood, 0.00, 0.00},
	Laminate_Oak     = {Color3.fromRGB(231, 231, 231), Enum.Material.Wood, 0.00, 0.00},
	Leaf_Palm        = {Color3.fromRGB( 58, 122,  53), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Leaf_Pothos      = {Color3.fromRGB( 47, 122,  46), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Leaf_Palm        = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Leaf_Pothos      = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Led_Downlight    = {Color3.fromRGB(255, 243, 229), Enum.Material.Neon, 0.00, 0.00},
	Led_Panel        = {Color3.fromRGB(250, 253, 255), Enum.Material.Neon, 0.00, 0.00},
	Led_Warm         = {Color3.fromRGB(255, 234, 206), Enum.Material.Neon, 0.00, 0.00},
	Led_Downlight    = {Color3.fromRGB(231, 231, 231), Enum.Material.Neon, 0.00, 0.00},
	Led_Panel        = {Color3.fromRGB(231, 231, 231), Enum.Material.Neon, 0.00, 0.00},
	Led_Warm         = {Color3.fromRGB(231, 231, 231), Enum.Material.Neon, 0.00, 0.00},
	Marble_Floor     = {Color3.fromRGB(216, 216, 213), Enum.Material.Marble, 0.05, 0.00},
	Mat_Sage         = {Color3.fromRGB(169, 191, 174), Enum.Material.Fabric, 0.00, 0.00},
	Mat_Sage         = {Color3.fromRGB(231, 231, 231), Enum.Material.Fabric, 0.00, 0.00},
	Mirror           = {Color3.fromRGB(220, 225, 228), Enum.Material.SmoothPlastic, 0.90, 0.00},
	Mirror_001       = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Paint_White      = {Color3.fromRGB(239, 239, 236), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Paper            = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Paper_001        = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plant_Stem       = {Color3.fromRGB( 92, 127,  58), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Plant_Stem       = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.02, 0.00},
	Plastic_Dark     = {Color3.fromRGB( 43,  45,  48), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plastic_Grey     = {Color3.fromRGB(143, 147, 152), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plastic_White    = {Color3.fromRGB(242, 242, 240), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plastic_Dark     = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plastic_Grey     = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Plastic_White    = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Rubber_Black     = {Color3.fromRGB( 21,  21,  21), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Rubber_Black     = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Sensor_Black     = {Color3.fromRGB(  8,   8,  10), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Sensor_Black     = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Smoke_Window     = {Color3.fromRGB( 58,  64,  72), Enum.Material.Glass, 0.05, 0.30},
	Smoke_Window     = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.30},
	Soil             = {Color3.fromRGB(231, 231, 231), Enum.Material.Ground, 0.00, 0.00},
	Soil_001         = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Solid_Surface    = {Color3.fromRGB(241, 241, 238), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Solid_Surface    = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Steel_Brushed    = {Color3.fromRGB(218, 218, 218), Enum.Material.Metal, 0.15, 0.00},
	Steel_Brushed    = {Color3.fromRGB(231, 231, 231), Enum.Material.SmoothPlastic, 0.00, 0.00},
	Tile_Lilac       = {Color3.fromRGB(118,  96, 176), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Tile_Sage        = {Color3.fromRGB(110, 155, 132), Enum.Material.SmoothPlastic, 0.08, 0.00},
	Touch_Icon       = {Color3.fromRGB(255, 255, 255), Enum.Material.Neon, 0.00, 0.00},
	Touch_Icon       = {Color3.fromRGB(231, 231, 231), Enum.Material.Neon, 0.00, 0.00},
	Towel_Cream      = {Color3.fromRGB(236, 230, 218), Enum.Material.Fabric, 0.00, 0.00},
	Towel_Cream      = {Color3.fromRGB(231, 231, 231), Enum.Material.Fabric, 0.00, 0.00},
	Water            = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.50},
	Water_001        = {Color3.fromRGB(231, 231, 231), Enum.Material.Glass, 0.05, 0.35},
}

-- Roblox asset id of art_print.png once uploaded (Asset Manager), e.g.
-- "rbxassetid://1234567890". Leave empty to keep the print a flat colour.
local ART_PRINT_TEXTURE = ""

local Selection = game:GetService("Selection")
local styled, unknown = 0, {}
local roots = Selection:Get()
if #roots == 0 then roots = {workspace} end
for _, root in ipairs(roots) do
	for _, part in ipairs(root:GetDescendants()) do
		if part:IsA("MeshPart") then
			local key = string.match(part.Name, "__([%w_]+)$")
			local s = key and STYLES[key]
			if s then
				part.Color = s[1]
				part.Material = s[2]
				part.Reflectance = s[3]
				part.Transparency = s[4]
				part.CastShadow = s[4] < 0.5
				if key == "Art_Print" and ART_PRINT_TEXTURE ~= "" then
					part.TextureID = ART_PRINT_TEXTURE
					part.Color = Color3.new(1, 1, 1)
				end
				part.Anchored = true
				styled += 1
			elseif key then
				unknown[key] = true
			end
		end
	end
end
print(("Bathroom: styled %d parts"):format(styled))
for key in pairs(unknown) do warn("Bathroom: no style for " .. key) end
